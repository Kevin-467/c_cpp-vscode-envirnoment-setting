#include <windows.h>
#include <mmsystem.h>
#include <dsound.h>

#include <initguid.h>
#include <amaudio.h>
#include <evr.h>
